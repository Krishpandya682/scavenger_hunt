import 'package:flutter/material.dart';

const textInputDecoration = InputDecoration();

const int LEVELS_PER_STAGE = 3;
const int TOTAL_STAGES = 4;

final snackBar = SnackBar(content: Text('Wrong...Try Again!'));
