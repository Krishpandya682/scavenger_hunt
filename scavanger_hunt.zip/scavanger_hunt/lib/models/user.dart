class MyUser {
  final String uid;
  MyUser({this.uid});
}
