import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class NumericalValues extends StatefulWidget {
  @override
  _NumericalValuesState createState() => _NumericalValuesState();
}

class _NumericalValuesState extends State<NumericalValues> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text('Numerical Values form'),
    );
  }
}
